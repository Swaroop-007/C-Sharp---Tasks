﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Exercises
{
    class RemoveNeg
    {
        public static void Main(string[] args)
        {
            List<int> seq = new List<int>();
            string a = Console.ReadLine();
            while (a != string.Empty)
            {
                int n = int.Parse(a);
                seq.Add(n);
                a = Console.ReadLine();

            }
            int j = 0;
            seq.Sort();
            foreach (int i in seq)
            {
                if (i < 0)
                    j++;
            }
            seq.RemoveRange(0, j);
            Console.WriteLine("The new Sequence is: ");
            foreach (int i in seq)
            {
                Console.Write(i + " ");
            }


        }
    }
}
