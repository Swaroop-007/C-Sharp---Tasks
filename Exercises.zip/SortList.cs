﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Exercises
{
    class SortList
    {
        public static void Main(string[] args)
        {
            List<int> seq = new List<int>();
            string a = Console.ReadLine();
            while (a != string.Empty)
            {
                int n = int.Parse(a);
                seq.Add(n);
                a = Console.ReadLine();

            }
            seq.Sort();
            Console.WriteLine("The new Sequence is: ");
            foreach(int i in seq)
            {
                Console.Write(i + " ");
            }

      
        }
    }
}
