﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercises
{
    class RemoveOddCount
    {
        public static void Main()
        {
            Dictionary<int, int> dict = new Dictionary<int, int>();
            List<int> seq = new List<int>();
            string a = Console.ReadLine();
            while (a != string.Empty)
            {
                int n = int.Parse(a);
                seq.Add(n);
                a = Console.ReadLine();

            }
            int count = seq.Count;
            for (int i = 0; i < count; i++)
            {
                if (dict.ContainsKey(seq[i]))
                {
                    int value = dict[seq[i]];
                    dict.Remove(seq[i]);
                    dict.Add(seq[i], value + 1);
                }
                else
                    dict.Add(seq[i], 1);
            }
            foreach (KeyValuePair<int, int> val in dict)
            {
                if (val.Value % 2 == 0)
                    Console.Write(val.Key + " ");

            }
        }
    }
}
