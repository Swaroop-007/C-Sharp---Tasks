﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercises
{
    class Student
    {
        public int regno;
        public string name;

    }
    class Science : Student
    {
        int Phy, Chem, math;
        public Science(int regno, string name, int Phy, int Chem, int math)
        {
            this.regno = regno;
            this.name = name;
            this.Phy = Phy;
            this.Chem = Chem;
            this.math = math;
        }
        public void Display()
        {
            Console.WriteLine($"The Registration Number : {this.regno}");
            Console.WriteLine($"The Student Name: {this.name}");
            Console.WriteLine($"Physics : {this.Phy}");
            Console.WriteLine($"Chemistry : {this.Chem}");
            Console.WriteLine($"Maths : {this.math}");
            Console.WriteLine($"The Average Marks obtained : {(double)(this.Phy + this.Chem + this.math) / 3}");
        }

        class Commerce : Student
        {
            int eco, acc, bank;
            public Commerce(int regno, string name, int eco, int acc, int bank)
            {
                this.regno = regno;
                this.name = name;
                this.eco = eco;
                this.acc = acc;
                this.bank = bank;
            }
            public void Display()
            {
                Console.WriteLine($"The Registration Number : {this.regno}");
                Console.WriteLine($"The Student Name: {this.name}");
                Console.WriteLine($"Economics : {this.eco}");
                Console.WriteLine($"Accounting : {this.acc}");
                Console.WriteLine($"Banking : {this.bank}");
                Console.WriteLine($"The Average Marks obtained : {(double)(this.eco + this.acc + this.bank) / 3}");
            }
        }
        class StudentDetails
        {
            public static void Main()
            {
                Science sc1 = new Science(1234, "Swa", 98, 99, 95);
                sc1.Display();
                Commerce c1 = new Commerce(1245, "Ar", 100, 95, 99);
                c1.Display();
            }
        }
    }
}