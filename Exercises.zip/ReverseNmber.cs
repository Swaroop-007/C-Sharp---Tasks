﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercises
{
    class ReverseNmber
    {
        
    
        public static Stack<int> stack = new Stack<int>();

        public static void push_number(int num)
        {
            while (num != 0)
            {
                stack.Push(num % 10);
                num = num / 10;
            }
        }
        public static int reverse_num(int num)
        {
            push_number(num);
            int rev = 0;
            int d = 1;
            while (stack.Count > 0)
            {
                rev = rev + (stack.Peek() * d);
                stack.Pop();
                d = d * 10;
            }
            return rev;
        }
        static void Main()
        {
            int input = int.Parse(Console.ReadLine());
            Console.WriteLine(reverse_num(input));


        }

    }

}
