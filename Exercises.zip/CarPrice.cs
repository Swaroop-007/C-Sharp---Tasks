﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercises
{   public interface Car
    {
        string price();
    }
    public class Mercedes : Car
    {
        public string price()
        {
            return $"The Price of Mercedes in INR is 8000000";
        }
    }
    public class BMW : Car
    {
        public string price()
        {
            return $"The Price of BMW in INR is 6000000";
        }
    }
    class CarPrice
    {
        public static void Main()
        {
            Car C;
            C = new Mercedes();
            Console.WriteLine(C.price());
            C = new BMW();
            Console.WriteLine(C.price());
        }
    }
}
