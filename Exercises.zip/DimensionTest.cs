﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercises
{   class Dimension
    {

        public double x, y;
        public Dimension(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
        public virtual void area()
        {
            double area = 0.0;
            area = x * y;
            Console.WriteLine("The area is {0}", area);
        }
    }
    class Circle: Dimension
    {
        public Circle(double x, double y) : base(x, y)
        {
            
        }
        public override void area()
        {
            double area = 0.0;
            area = Math.PI * x * x * y;
            Console.WriteLine("The area of Circle is {0}", Math.Round(area, 2));

        }
    }
    class Cylinder : Dimension
    {
        public Cylinder(double x, double y) : base(x, y)
        {

        }
        public override void area()
        {
            double area = 0.0;
            area = 2*Math.PI*x*y+2*Math.PI*x*x;
            Console.WriteLine("The area of Circle is {0}", Math.Round(area, 2));

        }
    }
    class Sphere : Dimension
    {
        public Sphere(double x, double y) : base(x, y)
        {

        }
        public override void area()
        {
            double area = 0.0;
            area = 4*Math.PI * x * x * y;
            Console.WriteLine("The area of Circle is {0}", Math.Round(area,2));

        }
    }
    class DimensionTest
    {
        public static void Main()
        {
            Circle c = new Circle(4, 1);
            c.area();
            Cylinder cy = new Cylinder(8, 9);
            cy.area();
            Sphere sp = new Sphere(10, 1);
            sp.area();
        }
        
    }
}
