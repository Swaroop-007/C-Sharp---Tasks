﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercises
{   class Employee
    {
        int empno;
        string name;
        string address;
        int pin;
        int phno;
        double grossSal;
        double pf;
        public Employee(int empno,string name, string address, int pin, int phno, double grossSal,double pf)
        {
            this.empno = empno;
            this.name = name;
            this.address = address;
            this.pin = pin;
            this.phno = phno;
            this.grossSal = grossSal;
            this.pf = pf;
        }

        public void netSalDisplay()
        {
            Console.WriteLine($"The Net Salary of Employee {this.name} is {this.grossSal - this.pf}");
        }
        public char Grades()
        {
            if ((this.grossSal - this.pf) > 10000)
                return 'A';
            else if ((this.grossSal - this.pf) < 5000)
                return 'C';
            else
                return 'B';
        }
    }
    class NetSalGrade
    {
        public static void Main()
        {
            Employee e = new Employee(2021, "Swa", "Bnagalore, India", 560078, 123456789, 12500, 2000);
            e.netSalDisplay();
            Console.WriteLine($"The Employee Grade is {e.Grades()}");
        }
    }
}
