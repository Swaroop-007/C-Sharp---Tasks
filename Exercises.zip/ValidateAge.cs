﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercises
{
    class ValidateAge
    {   class AgeException: Exception
        {
            public AgeException(string mes)
            {
                Console.WriteLine(mes);
            }
        }
        public static void Main()
        {
            Console.Write("Enter Your Age:  ");
            int age = int.Parse(Console.ReadLine());
            try
            {
                if (age < 18)
                {
                    throw new AgeException("Your Age is Invalid");
                }
                else
                    Console.WriteLine("Your Age is Valid");
            }
            catch(AgeException a)
            {
                Console.WriteLine(a);
            }

        }
    }
}
