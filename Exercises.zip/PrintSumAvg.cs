﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace Exercises
{
    class PrintSumAvg
    {
        static void Main(string[] args) {
            List<int> seq = new List<int>();
            string a = Console.ReadLine();
            while (a != string.Empty)
            {
               int n= int.Parse(a);
               seq.Add(n);
               a = Console.ReadLine();

            }
            Console.WriteLine("The Sum of sequence is : {0}",seq.Sum());
            Console.WriteLine("The Average of sequence is : {0}", seq.Average());

                }
        

    }
}
