﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercises
{
    struct Person_Details
    {
        public string name;
        public string sex;
        public double height;
        public double weight;

    }
    class Structure
    {
        public static void Main()
        {
            Person_Details P;
            P.name = "Swdasd";
            P.sex = "male";
            P.height = 180.1;
            P.weight = 75.6;
            Console.WriteLine($"The Person's name is {P.name}, sex is {P.sex}, Height in cms is {P.height} and Weight in Kgs is {P.weight}");
        }
        
    }
}
